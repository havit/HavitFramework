﻿using System;

namespace TB.ComponentModel.Tests.Unit {

    [Flags]
    public enum FlagsTestEnum {
        Value1 = 1,
        Value2 = 2,
        Value4 = 4
    }
}
