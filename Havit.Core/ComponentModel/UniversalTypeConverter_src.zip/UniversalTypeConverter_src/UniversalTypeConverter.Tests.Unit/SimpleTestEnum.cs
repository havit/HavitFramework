﻿namespace TB.ComponentModel.Tests.Unit {

    public enum SimpleTestEnum {
        Value0 = 0,
        Value1 = 1
    }
}
